<?php

define("WPML_SHOW_RSS", true);
define("WPML_SHOW_SUPPORT", true);
if (!defined('NEWSLETTERS_MANAGER_URL')) { define('NEWSLETTERS_MANAGER_URL', "https://tribulant.com/plugins/"); }

?>