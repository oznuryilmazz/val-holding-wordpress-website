tinyMCE.addI18n("en.Newsletters",{
	title : "Newsletters",
	desc : "Newsletter Functions"
});
