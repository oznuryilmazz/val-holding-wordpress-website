= Newsletter plugin languages =

See our documentation for detailed instructions on using language files: https://tribulant.com/docs/wordpress-mailing-list-plugin/80